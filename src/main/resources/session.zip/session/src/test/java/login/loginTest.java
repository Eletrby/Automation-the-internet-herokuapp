package login ;
import base.BaseTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

public class loginTest extends BaseTest {

    @Test (priority = 1)
    public void testSuccessfullLogin () {
        driver.findElement(By.cssSelector("a[href=\"/login\"]")).click();

        //Login
//
        driver.findElement(By.cssSelector("input[id=\"username\"]")).sendKeys("tomsmith");


        driver.findElement(By.cssSelector("input[id=\"password\"]")).sendKeys("SuperSecretPassword!");
        driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
        //Assertion
        String actualResult = driver.findElement(By.cssSelector("div[id=\"flash\"]")).getText();
        String expectedResult = "You logged into a secure area!";
        assertTrue(actualResult.contains(expectedResult));
    }

    //testCase2
    @Test (priority = 2)
    public void invalidUserName(){


        driver.findElement(By.cssSelector("a[href=\"/login\"]")).click();


        //Login
//
        driver.findElement(By.cssSelector("input[id=\"username\"]")).sendKeys("tomsmith1");

        driver.findElement(By.cssSelector("input[id=\"password\"]")).sendKeys("SuperSecretPassword!");
        driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();

        //Assertion
        String actualResult = driver.findElement(By.cssSelector("div[id=\"flash\"]")).getText();
        String expectedResult = "Your username is invalid!";
        assertTrue(actualResult.contains(expectedResult));

    }
    //testCase3
    @Test (priority = 3)
    public void password(){

        driver.findElement(By.cssSelector("a[href=\"/login\"]")).click();

        //Login
//
        driver.findElement(By.cssSelector("input[id=\"username\"]")).sendKeys("tomsmith");

        driver.findElement(By.cssSelector("input[id=\"password\"]")).sendKeys("SuperSecrePassword!");
        driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();

        //Assertion
        String actualResult = driver.findElement(By.cssSelector("div[id=\"flash\"]")).getText();
        String expectedResult = "Your password is invalid!";
        assertTrue(actualResult.contains(expectedResult));

    }


}

