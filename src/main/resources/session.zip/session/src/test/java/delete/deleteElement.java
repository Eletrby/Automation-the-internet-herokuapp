package delete;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class deleteElement extends BaseTest {
    @Test
    public void deleteElementTest () throws InterruptedException {
        driver.findElement(By.cssSelector("a[href=\"/add_remove_elements/\"]")).click();
        driver.findElement(By.cssSelector("button[onclick=\"addElement()\"]")).click();
        driver.findElement(By.cssSelector("button[class=\"added-manually\"]")).isDisplayed();
        Thread.sleep(3000);
    }

}
