package status;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

public class statusCode extends BaseTest {
@Test
    public void statusCodeTest(){
    driver.findElement(By.cssSelector("a[href=\"/status_codes\"]")).click();
    driver.findElement(By.cssSelector("a[href=\"status_codes/200\"]")).click();
    String actualResult = driver.findElement(By.cssSelector("div[class=\"example\"]")).getText();
    String expectedResult = "This page returned a 200 status code.";
    assertTrue(actualResult.contains(expectedResult));



    //assertion


}
}
