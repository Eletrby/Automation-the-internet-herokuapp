package checkBoxes;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class checkBoxesTests extends BaseTest {

    @Test
    public void checkBox() throws InterruptedException {
        driver.findElement(By.cssSelector("a[href=\"/checkboxes\"]")).click();
        driver.findElement(By.cssSelector("input[type=\"checkbox\"]")).click();
        Thread.sleep(300);

    }
}
