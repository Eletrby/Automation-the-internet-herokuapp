package upload;

import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class fileUpload extends BaseTest {
    @Test
    public void fileUploadTest () throws InterruptedException {
        driver.findElement(By.cssSelector("a[href=\"/upload\"]")).click();
       // driver.findElement(By.cssSelector("input[id=\"file-upload\"]")).click();
        WebElement chooseFile = driver.findElement(By.cssSelector("input[id=\"file-upload\"]"));
        chooseFile.sendKeys("E:\\SWE\\Automation\\Level1\\Session one\\session\\Session1.1\\download.jpg");
        driver.findElement(By.cssSelector("input[id=\"file-submit\"]")).click();
        Thread.sleep(10000);


    }
}
