package forget;

import base.BaseTest;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

public class forgetPassword extends BaseTest {
    @Test
    public void forgetPsswordTest () throws InterruptedException {
        driver.findElement(By.cssSelector("a[href=\"/forgot_password\"]")).click();
        driver.findElement(By.cssSelector("input[id=\"email\"]")).sendKeys("mahmoudeletrby1@gmail.com");
        driver.findElement(By.cssSelector("button[id=\"form_submit\"]")).click();
        Thread.sleep(5000);

        //Assertion
        String actualResult = driver.findElement(By.xpath("/html/body/h1")).getText();
        String expectedResult = "Internal Server Error";
        assertTrue(actualResult.contains(expectedResult));



    }
}
